# pafonline

# 'SellNBye' System 

### 1. You can clone it from github by running following command

```
  $ git clone https://github.com/Chamu97/pafonline.git
```

### 2. Import project into eclipse
```
  File -> Import -> General -> Projects from Folder or Achive -> Diectory/Achive -> Browse Project from cloned location -> Finish
```
### 3. Right click on project in eclipse and then Maven -> Update Projects 

### 4. Create MySQL database

### 5. Update database credential

### 6. Update your port number as your tomcat port number
```
http://localhost:8089/sellnbye/api/product
```

```
### 7. Right click on project Run As > Run on Server